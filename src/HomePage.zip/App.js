import React from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
// import ComponentWithProps from './ComponentWithProps';
import HomePage from './HomePage';
import PlaceDetails from './PlaceDetails';


function App() {
  return (
    <Router>
      <div>
        <Route path="/" exact>
          <HomePage />
        </Route>

        <Route path="/place/:id" component={PlaceDetails} />


      </div>
    </Router>
  );
}

export default App;
